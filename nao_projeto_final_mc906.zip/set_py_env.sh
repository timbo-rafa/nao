PYTHONSDK=/opt/vrep/pynaoqi-python2.7-2.1.4.13-linux64
export PYTHONPATH=${PYTHONPATH}:${PYTHONSDK}
