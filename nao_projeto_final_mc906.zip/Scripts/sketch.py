def readTrainSet():
  train_set = []
  for filename in glob.glob(TRAIN_SET):
    #get the image from file and use the most important central rectangle
    im = I.open(filename).crop((160, 0, 480, 480))
    width, height = im.size
    print("Loaded " + filename + " {w}x{h}".format(w=width, h=height))
    #extract features from the image(its pixels)
    pixels = imageIntoFeatures(im)
    #supervised learning: what is the expected answer for this input?
    isPlant = isPlantPicture(filename)
    answer = expected_answer(isPlant)
    train_set.append( Trainer( filename, pixels, answer ) )
  print("Loaded {n} images. {p} features each".format(
    n=len(train_set), p=len(train_set[0].inputs)))

  return train_set
