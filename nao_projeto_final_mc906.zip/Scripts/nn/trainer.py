class Trainer():
  def __init__(self, name, inputs, answer):
    self.name = name
    self.inputs = inputs
    self.answer = answer
